from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from datetime import datetime, time, timedelta
from typing import List
import uuid

app = FastAPI(title="Dental Appointment Booking API")

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000"],  # React app URL
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Data Models
class AppointmentCreate(BaseModel):
    patient_name: str
    contact_info: str
    appointment_type: str
    date: str  # YYYY-MM-DD
    time: str  # HH:MM

class Appointment(BaseModel):
    id: str
    patient_name: str
    contact_info: str
    appointment_type: str
    duration: int
    date: str
    time: str

# In-memory database
appointments_db = [
    {
        "id": "1",
        "patient_name": "John Doe",
        "contact_info": "john@email.com",
        "appointment_type": "Regular Check-up",
        "duration": 30,
        "date": "2024-10-01",
        "time": "10:00"
    },
    {
        "id": "2",
        "patient_name": "Jane Smith", 
        "contact_info": "jane@email.com",
        "appointment_type": "Specific Treatment",
        "duration": 60,
        "date": "2024-10-01",
        "time": "14:30"
    }
]

# Configuration
APPOINTMENT_TYPES = {
    "Regular Check-up": 30,
    "Specific Treatment": 60,
    "Operation": 120
}

CLINIC_START = time(9, 30)   # 09:30
CLINIC_END = time(20, 0)     # 20:00
LUNCH_START = time(13, 0)    # 13:00
LUNCH_END = time(14, 0)      # 14:00

def generate_time_slots():
    """Generate all possible 30-minute slots"""
    slots = []
    current = datetime.combine(datetime.today().date(), CLINIC_START)
    end = datetime.combine(datetime.today().date(), CLINIC_END)
    
    while current < end:
        # Skip lunch break
        if not (LUNCH_START <= current.time() < LUNCH_END):
            slots.append(current.time().strftime("%H:%M"))
        current += timedelta(minutes=30)
    
    return slots

@app.get("/")
def read_root():
    return {"message": "Dental Appointment Booking API is running"}

@app.get("/appointments")
def get_appointments(date: str):
    """Get all appointments for a specific date"""
    booked = [apt for apt in appointments_db if apt["date"] == date]
    return {"appointments": booked}

@app.get("/allAvailableSlots")
def get_available_slots(date: str, type: str):
    """Get available slots for date and appointment type"""
    
    if type not in APPOINTMENT_TYPES:
        raise HTTPException(status_code=400, detail="Invalid appointment type")
    
    # Get all booked slots for the date
    booked_times = [apt["time"] for apt in appointments_db if apt["date"] == date]
    
    # Generate all possible slots
    all_slots = generate_time_slots()
    
    # Filter out booked slots
    available = [slot for slot in all_slots if slot not in booked_times]
    
    return {"available_slots": available}

@app.post("/appointments")
def create_appointment(appointment: AppointmentCreate):
    """Create new appointment"""
    
    # Validate appointment type
    if appointment.appointment_type not in APPOINTMENT_TYPES:
        raise HTTPException(status_code=400, detail="Invalid appointment type")
    
    # Check if slot is already booked
    booked_times = [
        apt["time"] for apt in appointments_db 
        if apt["date"] == appointment.date
    ]
    
    if appointment.time in booked_times:
        raise HTTPException(status_code=409, detail="Time slot already booked")
    
    # Create appointment
    new_appointment = {
        "id": str(uuid.uuid4()),
        "patient_name": appointment.patient_name,
        "contact_info": appointment.contact_info,
        "appointment_type": appointment.appointment_type,
        "duration": APPOINTMENT_TYPES[appointment.appointment_type],
        "date": appointment.date,
        "time": appointment.time
    }
    
    appointments_db.append(new_appointment)
    
    return {
        "message": "Appointment booked successfully", 
        "appointment": new_appointment
    }

@app.delete("/appointments/{appointment_id}")
def cancel_appointment(appointment_id: str):
    """Cancel appointment (for dentist)"""
    
    global appointments_db
    original_count = len(appointments_db)
    appointments_db = [apt for apt in appointments_db if apt["id"] != appointment_id]
    
    if len(appointments_db) == original_count:
        raise HTTPException(status_code=404, detail="Appointment not found")
    
    return {"message": "Appointment cancelled successfully"}

@app.get("/dentist/appointments")
def get_dentist_appointments(date: str):
    """Get all appointments for dentist dashboard"""
    
    daily_appointments = [
        apt for apt in appointments_db 
        if apt["date"] == date
    ]
    
    # Sort by time
    daily_appointments.sort(key=lambda x: x["time"])
    
    return {
        "date": date, 
        "total": len(daily_appointments),
        "appointments": daily_appointments
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)