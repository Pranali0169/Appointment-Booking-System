import React, { useState } from 'react';
import './App.css';

const App = () => {
  const [selectedType, setSelectedType] = useState('');
  const [selectedDate, setSelectedDate] = useState('');
  const [selectedSlot, setSelectedSlot] = useState('');
  const [patientName, setPatientName] = useState('');
  const [patientContact, setPatientContact] = useState('');
  const [isBooked, setIsBooked] = useState(false);
  const [availableSlots, setAvailableSlots] = useState([]);
  const [loading, setLoading] = useState(false);

  const appointmentTypes = [
    { value: 'Regular Check-up', label: 'Regular Check-up', duration: 30 },
    { value: 'Specific Treatment', label: 'Specific Treatment', duration: 60 },
    { value: 'Operation', label: 'Operation', duration: 120 }
  ];

  // Fetch available slots from backend
  const fetchAvailableSlots = async (date, type) => {
    setLoading(true);
    try {
      const response = await fetch(`http://localhost:8000/allAvailableSlots?date=${date}&type=${type}`);
      const data = await response.json();
      setAvailableSlots(data.available_slots || []);
    } catch (error) {
      console.error('Error fetching slots:', error);
      setAvailableSlots([]);
    }
    setLoading(false);
  };

  // Handle date selection
  const handleDateChange = (date) => {
    setSelectedDate(date);
    setSelectedSlot('');
    if (selectedType) {
      fetchAvailableSlots(date, selectedType);
    }
  };

  // Handle appointment type selection
  const handleTypeChange = (type) => {
    setSelectedType(type);
    setSelectedSlot('');
    if (selectedDate) {
      fetchAvailableSlots(selectedDate, type);
    }
  };

  // Book appointment
  const handleBooking = async () => {
    if (!patientName || !patientContact || !selectedSlot) {
      alert('Please fill all fields');
      return;
    }

    try {
      const response = await fetch('http://localhost:8000/appointments', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          patient_name: patientName,
          contact_info: patientContact,
          appointment_type: selectedType,
          date: selectedDate,
          time: selectedSlot
        })
      });

      if (response.ok) {
        setIsBooked(true);
      } else {
        const error = await response.json();
        alert(error.detail || 'Booking failed');
      }
    } catch (error) {
      console.error('Booking error:', error);
      alert('Booking failed. Please try again.');
    }
  };

  const resetForm = () => {
    setSelectedType('');
    setSelectedDate('');
    setSelectedSlot('');
    setPatientName('');
    setPatientContact('');
    setIsBooked(false);
    setAvailableSlots([]);
  };

  if (isBooked) {
    return (
      <div className="container">
        <div className="confirmation">
          <div className="success-icon">✓</div>
          <h2>Booking Confirmed!</h2>
          <div className="booking-details">
            <p><strong>Patient:</strong> {patientName}</p>
            <p><strong>Date:</strong> {selectedDate}</p>
            <p><strong>Time:</strong> {selectedSlot}</p>
            <p><strong>Type:</strong> {selectedType}</p>
          </div>
          <button onClick={resetForm} className="btn btn-primary">
            Book Another Appointment
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="container">
      <h1>Dental Appointment Booking</h1>

      {/* Step 1: Select Appointment Type */}
      <div className="section">
        <h3>Select Appointment Type</h3>
        <div className="type-grid">
          {appointmentTypes.map(type => (
            <button
              key={type.value}
              onClick={() => handleTypeChange(type.value)}
              className={`type-card ${selectedType === type.value ? 'selected' : ''}`}
            >
              <div className="type-label">{type.label}</div>
              <div className="type-duration">{type.duration} minutes</div>
            </button>
          ))}
        </div>
      </div>

      {/* Step 2: Select Date */}
      {selectedType && (
        <div className="section">
          <h3>Select Date</h3>
          <input
            type="date"
            value={selectedDate}
            onChange={(e) => handleDateChange(e.target.value)}
            min={new Date().toISOString().split('T')[0]}
            className="date-input"
          />
        </div>
      )}

      {/* Step 3: Select Time Slot */}
      {selectedDate && (
        <div className="section">
          <h3>Available Time Slots</h3>
          {loading ? (
            <p>Loading slots...</p>
          ) : (
            <div className="slots-grid">
              {availableSlots.map(slot => (
                <button
                  key={slot}
                  onClick={() => setSelectedSlot(slot)}
                  className={`slot-btn ${selectedSlot === slot ? 'selected' : ''}`}
                >
                  {slot}
                </button>
              ))}
            </div>
          )}
          {!loading && availableSlots.length === 0 && selectedDate && (
            <p className="no-slots">No slots available for this date</p>
          )}
        </div>
      )}

      {/* Step 4: Patient Details */}
      {selectedSlot && (
        <div className="section">
          <h3>Patient Details</h3>
          <div className="form-group">
            <input
              type="text"
              placeholder="Patient Name"
              value={patientName}
              onChange={(e) => setPatientName(e.target.value)}
              className="form-input"
            />
            <input
              type="text"
              placeholder="Contact Number/Email"
              value={patientContact}
              onChange={(e) => setPatientContact(e.target.value)}
              className="form-input"
            />
          </div>
        </div>
      )}

      {/* Book Button */}
      {patientName && patientContact && (
        <button
          onClick={handleBooking}
          className="btn btn-primary btn-large"
        >
          Confirm Booking
        </button>
      )}
    </div>
  );
};

export default App;